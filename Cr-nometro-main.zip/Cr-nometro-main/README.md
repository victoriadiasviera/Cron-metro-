# Cr-nometro
medir intervalos de tempo com aproximação de décimo de segundo ou menos.
